import { world, system } from "mojang-minecraft"
import { ActionFormData } from "mojang-minecraft-ui"


system.events.beforeWatchdogTerminate.subscribe(data => {
  data.cancel = true;
});


let w = world.getDimension("overworld");

world.events.beforeItemUse.subscribe(data => {
  var players = Array.from(world.getPlayers());
  var p = data.source
  if (data.item.id == "minecraft:air") return;
  switch (data.item.id) {
    case "emotes:emotes_item_click": {
      var form = new ActionFormData()
        form.title("EMOTES")
        form.body("Choose Your Emote")
        form.button("Page 1")
        form.button("Page 2")
        form.button("Page 3")
        form.button("Page 4")
        form.button("X");

      form.show(p).then((response) => {
        if (response.selection === 0) {
          var form = new ActionFormData()
            form.title("§l§oEMOTES")
            form.body("§l§oChoose Your Emote")
            form.button("§l§oDab", "textures/ui/dab")
            form.button("§l§oTwerking", "textures/ui/twerking")
            form.button("§l§oJijijija", "textures/ui/jijijija")
            form.button("§l§oCry", "textures/ui/cry")
            form.button("§l§oDesperate", "textures/ui/desesperate")
            form.button("§l§oX", "textures/ui/cancel");

          form.show(p).then((response) => {
            if (response.selection === 0) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.custom.dab animation.humanoid.custom.dab`)
            }
            else if (response.selection === 1) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.custom.perreo animation.humanoid.custom.perreo`)
            }
            else if (response.selection === 2) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.custom.risa animation.humanoid.custom.risa`)
            }
            else if (response.selection === 3) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.custom.llorar animation.humanoid.custom.llorar`)
            }
            else if (response.selection === 4) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.desesperado animation.humanoid.desesperado`)
            }
          });
        }
        else if (response.selection === 1) {
          var form = new ActionFormData()
          form.title("EMOTES")
          form.body("Choose Your Emote")
          form.button("T - Pose", "textures/ui/t-pose")
          form.button("Slap", "textures/ui/slap")
          form.button("Flip", "textures/ui/flip")
          form.button("Throwing Money", "textures/ui/throwing_money")
          form.button("Floss", "textures/ui/dance")
          form.button("X", "textures/ui/cancel");

          form.show(p).then((response) => {
            if (response.selection === 0) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.t-pose animation.humanoid.t-pose`)
            }
            else if (response.selection === 1) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.customm.cachetada animation.humanoid.customm.cachetada`)
            }
            else if (response.selection === 2) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.flip_atras animation.humanoid.flip_atras`)
            }
            else if (response.selection === 3) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.melapelas animation.humanoid.melapelas`)
            }
            else if (response.selection === 4) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.baile animation.humanoid.baile`)
            }
          });
        }
        else if (response.selection === 2) {
          var form = new ActionFormData()
          form.title("EMOTES")
          form.body("Choose Your Emote")
          form.button("Champion", "textures/ui/champion")
          form.button("You're Dead", "textures/ui/youredead")
          form.button("I'm Here", "textures/ui/imhere")
          form.button("Ñaca Ñaca", "textures/ui/ñacañaca")
          form.button("Arigato | Thanks", "textures/ui/arigato")
          form.button("X", "textures/ui/cancel");

          form.show(p).then((response) => {
            if (response.selection === 0) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.customm.campeon animation.humanoid.customm.campeon`)
            }
            else if (response.selection === 1) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.customm.muerto`)
            }
            else if (response.selection === 2) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.aquiestoy animation.humanoid.aquiestoy`)
            }
            else if (response.selection === 3) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.naca animation.humanoid.naca`)
            }
            else if (response.selection === 4) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.arigato animation.humanoid.arigato`)
            }
          });
        }
        else if (response.selection === 3) {
          var form = new ActionFormData()
          form.title("EMOTES")
          form.body("Choose Your Emote")
          form.button("Lie Down", "textures/ui/liedown")
          form.button("Sitting", "textures/ui/sit")
          form.button("Take the L", "textures/ui/takethel")
          form.button("Best Mates", "textures/ui/bestmates")
          form.button("Idle", "textures/ui/idle")
          form.button("X", "textures/ui/cancel");

          form.show(p).then((response) => {
            if (response.selection === 0) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.customm.baile_16 acostarse 1000000`)
            }
            else if (response.selection === 1) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.customm.baile_17 sentarse 1000000`)
            }
            else if (response.selection === 2) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.customm.baile_18 animation.humanoid.customm.baile_18`)
            }
            else if (response.selection === 3) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.customm.baile_19 animation.humanoid.customm.baile_19`)
            }
            else if (response.selection === 4) {
              p.runCommand(`execute @a[name="${p.nameTag}"] ~ ~ ~ playanimation @a[name="${p.nameTag}"] animation.humanoid.customm.baile_20 animation.humanoid.customm.baile_20`)
            }
          });
        }
      });
    } break;
    default:
      break;
  }
});

world.events.tick.subscribe(function () {

  let levelPlayers = Array.from(world.getPlayers());

  levelPlayers.forEach(player => {
      if (player.velocity.x > 0 || player.velocity.z > 0 || player.velocity.y > 0) {

        player.runCommand(`playanimation @s animation.humanoid.base_pose`);
      } else if (player.isSneaking) {

        player.runCommand(`playanimation @s animation.humanoid.base_pose`);

      }
  });
});


world.events.beforeChat.subscribe((emotes) => {
  let prefix = 'c/';
  let msg = emotes.message;
  let command = 'emotes';

  if (msg.toLowerCase().startsWith(prefix + command)) {
    emotes.cancel = true;
    w.runCommand(`execute @a[name="${emotes.sender.nameTag}"] ~ ~ ~ give @a[name="${emotes.sender.nameTag}"] emotes:emotes_item_click`)
  }
  else if (msg.toLowerCase().includes(prefix + !command)) {
    emotes.cancel = true;
    w.runCommand(`execute @a[name="${emotes.sender.nameTag}"] ~ ~ ~ tellraw @a[name="${emotes.sender.nameTag}"] {"rawtext":[{"text":"§4Unknown command §e${msg}"}]}`)
  }
});