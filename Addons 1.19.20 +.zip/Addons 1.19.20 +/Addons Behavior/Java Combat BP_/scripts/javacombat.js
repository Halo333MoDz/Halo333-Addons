import { world, system } from "mojang-minecraft";


system.events.beforeWatchdogTerminate.subscribe(data => {
    data.cancel = true;
  });

world.events.entityHurt.subscribe((hurt) => {
    let hurtEntity = hurt.hurtEntity;
    let hurtDamager = hurt.damagingEntity;
    let container = hurtDamager.getComponent("inventory").container;
    let hand = container.getItem(hurtDamager.selectedSlot);
    let id = hand.id;
    let axes = ["_axe", "poleaxe", "chopper", "tomahawk", "adze", "hatchet", "cleaver", "hacha"];
    let others = ["sword"];
    for (const itemsid of axes) {
        //hachas de otros addons 
        if (hurtDamager.id == "minecraft:player" && id.includes(itemsid)) {
            hurtEntity.addTag("hurted");
            hurtDamager.addTag("damager");
            hurtDamager.runCommand(`summon new:tagremove_axe`);
            hurtDamager.runCommand(`particle new:6dad269a-4a3a-41b7-977e-b4c75ca6ca63 ^ ^1 ^1`);
            hurtDamager.runCommand(`playsound 6dad269a-4a3a-41b7-977e-b4c75ca6ca63`);
            hurtDamager.runCommand(`effect @s mining_fatigue 2 5 true`);
            hurtDamager.runCommand(`effect @s weakness 2 255 true`);
        }
    }
    for (const otheritems of others) {
        //items normales
        if (hurtDamager.id == 'minecraft:player' && id.includes(otheritems)) {
            hurtDamager.addTag("damager");
            hurtDamager.runCommand(`summon new:tagremove`);
            hurtDamager.runCommand(`particle new:6dad269a-4a3a-41b7-977e-b4c75ca6ca63 ^ ^1 ^1`);
            hurtDamager.runCommand(`playsound 6dad269a-4a3a-41b7-977e-b4c75ca6ca63`);
            hurtDamager.runCommand(`effect @s mining_fatigue 1 5 true`);
            hurtDamager.runCommand(`effect @s weakness 1 255 true`);
        }
    }
});